package com.example.weight_tracking_app2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.app.Activity;
import android.graphics.Color;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {

    Button but1,but2;
    EditText edit1,edit2;

    TextView tex1;
    int counter = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        but1 = (Button) findViewById(R.id.button);
        edit1 = (EditText) findViewById(R.id.editText);
        edit2 = (EditText) findViewById(R.id.editText2);

        but2 = (Button) findViewById(R.id.button2);
        tex1 = (TextView) findViewById(R.id.textView3);
        tex1.setVisibility(View.GONE);

        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.getText().toString().equals("admin") &&
                        edit2.getText().toString().equals("admin")) {
                    Toast.makeText(getApplicationContext(), "Redirecting..",
                            Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Invalid Credentials",
                            Toast.LENGTH_SHORT).show();
                    tex1.setVisibility(View.VISIBLE);
                    tex1.setBackgroundColor(Color.RED);
                    counter--;
                    tex1.setText(Integer.toString(counter));

                    if(counter == 0){
                        but1.setEnabled(false);
                    }

                }
            }
        });

       but2.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               finish();

           }

        });
    }
}