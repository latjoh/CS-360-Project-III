package com.example.weight_tracking_app2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;

public class WeightDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "weight.db";
    private static final int VERSION = 2;

    public WeightDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);

    }

    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table" + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + "integer primary key autoincrement, " +
                WeightTable.COL_DATE + " text," +
                WeightTable.COL_WEIGHT + " float)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists" + WeightTable.TABLE);
        onCreate(db);
    }



    public long addWeight() {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_DATE, " ");
        values.put(WeightTable.COL_WEIGHT, " ");

        long weightId = db.insert(WeightTable.TABLE, null, values);
        return weightId;
    }

}